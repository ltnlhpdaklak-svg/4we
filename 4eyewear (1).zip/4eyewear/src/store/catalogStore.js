import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import { CATEGORIES, PRODUCTS } from '../data/mockData.js'
import { slugify } from '../utils/format.js'

// Danh mục và sản phẩm. Giai đoạn 1-2 lưu trên trình duyệt.
// Giai đoạn 3-4: thay bằng truy vấn tới bảng products, categories trong Supabase.
export const useCatalogStore = create()(
  persist(
    (set, get) => ({
      categories: CATEGORIES,
      products: PRODUCTS,

      addProduct: (data) => {
        const now = new Date().toISOString()
        const product = {
          ...data,
          id: `p-${Date.now()}`,
          slug: slugify(data.name) || `san-pham-${Date.now()}`,
          is_active: data.is_active ?? true,
          sold_count: 0,
          view_count: 0,
          created_at: now,
          updated_at: now,
        }
        set((s) => ({ products: [product, ...s.products] }))
        return product
      },

      updateProduct: (id, patch) =>
        set((s) => ({
          products: s.products.map((p) =>
            p.id === id
              ? { ...p, ...patch, slug: patch.name ? slugify(patch.name) : p.slug, updated_at: new Date().toISOString() }
              : p
          ),
        })),

      deleteProduct: (id) => set((s) => ({ products: s.products.filter((p) => p.id !== id) })),

      incrementView: (id) =>
        set((s) => ({
          products: s.products.map((p) => (p.id === id ? { ...p, view_count: (p.view_count ?? 0) + 1 } : p)),
        })),

      // Trừ tồn kho và cộng số lượng đã bán sau khi đặt hàng thành công
      recordSale: (lines) =>
        set((s) => {
          const qtyById = Object.fromEntries(lines.map((l) => [l.product_id, l.quantity]))
          return {
            products: s.products.map((p) => {
              const qty = qtyById[p.id]
              if (!qty) return p
              return { ...p, stock: Math.max(0, p.stock - qty), sold_count: (p.sold_count ?? 0) + qty }
            }),
          }
        }),

      // Hoàn tồn kho khi đơn đã trừ kho bị hủy
      restoreStock: (lines) =>
        set((s) => {
          const qtyById = Object.fromEntries(lines.map((l) => [l.product_id, l.quantity]))
          return {
            products: s.products.map((p) => {
              const qty = qtyById[p.id]
              if (!qty) return p
              return { ...p, stock: p.stock + qty, sold_count: Math.max(0, (p.sold_count ?? 0) - qty) }
            }),
          }
        }),

      addCategory: (data) => {
        const category = {
          ...data,
          id: `cat-${Date.now()}`,
          slug: slugify(data.name),
          created_at: new Date().toISOString(),
        }
        set((s) => ({ categories: [...s.categories, category] }))
        return category
      },

      updateCategory: (id, patch) =>
        set((s) => ({
          categories: s.categories.map((c) =>
            c.id === id ? { ...c, ...patch, slug: patch.name ? slugify(patch.name) : c.slug } : c
          ),
        })),

      // Không cho xóa danh mục đang có sản phẩm. Trả về false nếu không xóa được.
      deleteCategory: (id) => {
        const inUse = get().products.some((p) => p.category_id === id)
        if (inUse) return false
        set((s) => ({ categories: s.categories.filter((c) => c.id !== id) }))
        return true
      },
    }),
    {
      name: 'eyewear-catalog',
      version: 1,
      storage: createJSONStorage(() => localStorage),
    }
  )
)
