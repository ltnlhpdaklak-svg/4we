import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import { SEED_ORDERS } from '../data/mockData.js'
import { useCatalogStore } from './catalogStore.js'

// Đơn hàng. Giai đoạn 1-2 lưu trên trình duyệt.
// Giai đoạn 3-4: đơn được tạo bằng PostgreSQL function (RPC) trong Supabase để đảm bảo nguyên tử.
export const useOrderStore = create()(
  persist(
    (set, get) => ({
      orders: SEED_ORDERS,

      addOrder: (order) => set((s) => ({ orders: [order, ...s.orders] })),

      updateStatus: (id, status) => {
        const current = get().orders.find((o) => o.id === id)
        // Đơn đã hủy không đổi trạng thái nữa
        if (!current || current.status === status || current.status === 'Đã hủy') return

        // Hủy đơn đã trừ kho thì hoàn lại tồn kho.
        // Đơn mẫu ban đầu không có cờ stock_reserved nên không hoàn kho.
        if (status === 'Đã hủy' && current.stock_reserved) {
          useCatalogStore.getState().restoreStock(current.items)
        }

        set((s) => ({
          orders: s.orders.map((o) =>
            o.id === id
              ? {
                  ...o,
                  status,
                  payment_status: status === 'Đã giao hàng' ? 'Đã thanh toán' : o.payment_status,
                  updated_at: new Date().toISOString(),
                }
              : o
          ),
        }))
      },
    }),
    {
      name: 'eyewear-orders',
      version: 1,
      storage: createJSONStorage(() => localStorage),
    }
  )
)
