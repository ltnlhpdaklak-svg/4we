import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'

// Nhật ký sự kiện Marketing (xem trang Thống kê). Giới hạn 2000 bản ghi gần nhất.
const MAX_EVENTS = 2000

export const useEventStore = create()(
  persist(
    (set) => ({
      events: [],
      track: (event) => set((s) => ({ events: [...s.events, event].slice(-MAX_EVENTS) })),
    }),
    {
      name: 'eyewear-events',
      version: 1,
      storage: createJSONStorage(() => localStorage),
    }
  )
)
