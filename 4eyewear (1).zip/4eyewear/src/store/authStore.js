import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import { DEMO_ACCOUNTS, SEED_USERS } from '../data/mockData.js'

// XÁC THỰC GIẢ LẬP cho Giai đoạn 1-2. Giai đoạn 4 thay bằng Supabase Auth.
// Không lưu mật khẩu trong state. Tài khoản demo kiểm tra theo DEMO_ACCOUNTS.
// Tài khoản đăng ký mới chỉ cần mật khẩu từ 6 ký tự (chỉ để demo).

const sameEmail = (a, b) => a.trim().toLowerCase() === b.trim().toLowerCase()

const normalizeAddresses = (list) => {
  if (!list.length) return list
  const hasDefault = list.some((a) => a.is_default)
  return list.map((a, idx) => ({ ...a, is_default: hasDefault ? a.is_default : idx === 0 }))
}

export const useAuthStore = create()(
  persist(
    (set, get) => {
      const applyUser = (nextUser) =>
        set((s) => ({
          user: nextUser,
          users: s.users.map((u) => (u.id === nextUser.id ? nextUser : u)),
        }))

      return {
        user: null,
        users: SEED_USERS,

        login: (email, password) => {
          const found = get().users.find((u) => sameEmail(u.email, email))
          if (!found) return { error: 'Email hoặc mật khẩu không đúng.' }

          const seedIds = SEED_USERS.map((u) => u.id)
          let ok
          if (seedIds.includes(found.id)) {
            const demo = DEMO_ACCOUNTS.find((acc) => sameEmail(acc.email, found.email))
            ok = demo && password === demo.password
          } else {
            ok = password.length >= 6
          }
          if (!ok) return { error: 'Email hoặc mật khẩu không đúng.' }

          set({ user: found })
          return { ok: true, user: found }
        },

        register: ({ full_name, email }) => {
          const exists = get().users.some((u) => sameEmail(u.email, email))
          if (exists) return { error: 'Email này đã được đăng ký.' }

          const user = {
            id: `u-${Date.now()}`,
            email: email.trim(),
            full_name: full_name.trim(),
            phone: '',
            role: 'customer',
            status: 'Hoạt động',
            created_at: new Date().toISOString(),
            addresses: [],
          }
          set((s) => ({ users: [user, ...s.users], user }))
          return { ok: true, user }
        },

        logout: () => set({ user: null }),

        updateProfile: (patch) => {
          const current = get().user
          if (!current) return
          applyUser({ ...current, ...patch })
        },

        saveAddress: (addr) => {
          const current = get().user
          if (!current) return
          const list = current.addresses ?? []
          const payload = { ...addr, id: addr.id ?? `a-${Date.now()}` }
          let next = addr.id ? list.map((a) => (a.id === addr.id ? payload : a)) : [...list, payload]
          if (payload.is_default) {
            next = next.map((a) => ({ ...a, is_default: a.id === payload.id }))
          }
          applyUser({ ...current, addresses: normalizeAddresses(next) })
        },

        deleteAddress: (id) => {
          const current = get().user
          if (!current) return
          const next = (current.addresses ?? []).filter((a) => a.id !== id)
          applyUser({ ...current, addresses: normalizeAddresses(next) })
        },

        setDefaultAddress: (id) => {
          const current = get().user
          if (!current) return
          const next = (current.addresses ?? []).map((a) => ({ ...a, is_default: a.id === id }))
          applyUser({ ...current, addresses: next })
        },
      }
    },
    {
      name: 'eyewear-auth',
      version: 1,
      storage: createJSONStorage(() => localStorage),
    }
  )
)
