import { useCallback, useEffect, useState } from 'react'

// Giả lập thời gian tải để hiển thị skeleton đúng như khi có mạng thật.
// Khi nối Supabase (Giai đoạn 4), thay hook này bằng trạng thái tải thật của truy vấn.
export default function useSimulatedLoading(delay = 450) {
  const [loading, setLoading] = useState(true)
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), delay)
    return () => clearTimeout(timer)
  }, [delay, attempt])

  const retry = useCallback(() => {
    setLoading(true)
    setAttempt((a) => a + 1)
  }, [])

  return { loading, retry }
}
