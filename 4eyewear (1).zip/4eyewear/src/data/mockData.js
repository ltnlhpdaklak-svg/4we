// DỮ LIỆU MẪU cho Giai đoạn 1-2 (giao diện và chức năng chạy trên trình duyệt).
// Ở Giai đoạn 3-4, dữ liệu này được thay bằng bảng thật trong Supabase (xem supabase/migrations).
import { effectivePrice, formatAddress } from '../utils/format.js'

export const CATEGORIES = [
  { id: 'cat-kinh-ram', name: 'Kính râm', slug: 'kinh-ram', icon: 'Sun', description: 'Bảo vệ mắt khỏi tia UV, phong cách thời trang.' },
  { id: 'cat-kinh-can', name: 'Kính cận', slug: 'kinh-can', icon: 'Eye', description: 'Gọng và tròng cận, có thể cắt theo độ.' },
  { id: 'cat-gong-kinh', name: 'Gọng kính', slug: 'gong-kinh', icon: 'Glasses', description: 'Gọng kính thời trang cho mọi khuôn mặt.' },
  { id: 'cat-kinh-the-thao', name: 'Kính thể thao', slug: 'kinh-the-thao', icon: 'Dumbbell', description: 'Kính ôm sát cho chạy bộ, đạp xe.' },
  { id: 'cat-kinh-tre-em', name: 'Kính trẻ em', slug: 'kinh-tre-em', icon: 'Baby', description: 'Gọng dẻo, an toàn cho bé.' },
  { id: 'cat-phu-kien', name: 'Phụ kiện', slug: 'phu-kien', icon: 'Sparkles', description: 'Hộp đựng, dây đeo và phụ kiện kính.' },
]

const makeProduct = (n, category_id, name, slug, description, price, sale_price, stock, sold_count, view_count, created) => ({
  id: `p${n}`,
  category_id,
  name,
  slug,
  description,
  price,
  sale_price,
  image_url: `/products/p${n}.svg`,
  stock,
  sold_count,
  view_count,
  is_active: true,
  created_at: `${created}T09:00:00+07:00`,
  updated_at: `${created}T09:00:00+07:00`,
})

export const PRODUCTS = [
  makeProduct(1, 'cat-kinh-ram', 'Kính râm Aviator gọng vàng', 'kinh-ram-aviator-vang',
    'Gọng kim loại mạ vàng, tròng phân cực giảm chói. Kiểu aviator cổ điển, hợp với nhiều khuôn mặt.',
    1290000, 990000, 25, 340, 1820, '2026-11-02'),
  makeProduct(2, 'cat-kinh-ram', 'Kính râm Wayfarer đen', 'kinh-ram-wayfarer-den',
    'Gọng nhựa dẻo nhẹ, chống tia UV400. Thiết kế vuông bo góc, dễ phối đồ hằng ngày.',
    890000, null, 40, 512, 2410, '2026-10-20'),
  makeProduct(3, 'cat-kinh-ram', 'Kính râm tròn retro nâu', 'kinh-ram-tron-retro-nau',
    'Gọng tròn phong cách retro, tròng nâu gradient. Chống tia UV400.',
    790000, 590000, 18, 205, 1330, '2026-11-10'),
  makeProduct(4, 'cat-gong-kinh', 'Gọng kính vuông titan bạc', 'gong-kinh-vuong-titan-bac',
    'Titan siêu nhẹ, không gây kích ứng da. Phù hợp đeo lâu dài.',
    1190000, null, 30, 98, 760, '2026-11-15'),
  makeProduct(5, 'cat-gong-kinh', 'Gọng kính tròn acetate xanh navy', 'gong-kinh-tron-acetate-xanh-navy',
    'Acetate cao cấp, màu xanh navy trầm. Bản lề chắc chắn.',
    690000, 549000, 12, 150, 930, '2026-10-28'),
  makeProduct(6, 'cat-gong-kinh', 'Gọng kính vuông acetate đỏ rượu', 'gong-kinh-vuong-acetate-do-ruou',
    'Gọng acetate đỏ rượu, dáng vuông cá tính. Hiện đang tạm hết hàng.',
    850000, null, 0, 64, 510, '2026-11-18'),
  makeProduct(7, 'cat-kinh-can', 'Kính cận wayfarer hồng pastel', 'kinh-can-wayfarer-hong-pastel',
    'Gọng nhẹ màu hồng pastel, có thể cắt tròng theo độ cận.',
    720000, 650000, 22, 77, 640, '2026-11-05'),
  makeProduct(8, 'cat-kinh-can', 'Kính cận vuông đen mỏng', 'kinh-can-vuong-den-mong',
    'Gọng kim loại đen mỏng, tròng chống ánh sáng xanh.',
    560000, null, 35, 133, 880, '2026-10-15'),
  makeProduct(9, 'cat-kinh-the-thao', 'Kính thể thao ôm sát xanh dương', 'kinh-the-thao-om-sat-xanh-duong',
    'Thiết kế ôm sát khi chạy bộ và đạp xe, tròng phân cực.',
    1490000, 1190000, 14, 56, 420, '2026-11-20'),
  makeProduct(10, 'cat-kinh-tre-em', 'Kính trẻ em tròn dẻo xanh lá', 'kinh-tre-em-tron-deo-xanh-la',
    'Gọng silicone dẻo, an toàn cho bé. Có dây đeo điều chỉnh.',
    350000, 290000, 50, 301, 1100, '2026-10-25'),
  makeProduct(11, 'cat-kinh-tre-em', 'Kính trẻ em vuông vàng', 'kinh-tre-em-vuong-vang',
    'Gọng nhựa dẻo màu vàng tươi. Số lượng còn ít.',
    320000, null, 3, 88, 390, '2026-11-12'),
  makeProduct(12, 'cat-phu-kien', 'Hộp đựng kính cứng', 'hop-dung-kinh-cung',
    'Hộp cứng chống va đập, lót nỉ mềm. Phù hợp mang theo khi đi du lịch.',
    120000, 99000, 60, 420, 1500, '2026-09-30'),
]

const makeAddress = (id, recipient_name, phone, province, district, ward, street_address) => ({
  id,
  recipient_name,
  phone,
  province,
  district,
  ward,
  street_address,
  is_default: true,
})

const makeUser = (id, email, full_name, phone, role, created_at, addresses = []) => ({
  id,
  email,
  full_name,
  phone,
  role,
  status: 'Hoạt động',
  created_at: `${created_at}T08:00:00+07:00`,
  addresses,
})

// Tài khoản demo. Mật khẩu chỉ dùng cho bản demo: khách "demo123", admin "admin123".
export const SEED_USERS = [
  makeUser('u-admin', 'admin@4eyewear.demo', 'Quản trị viên', '0900000000', 'admin', '2026-10-01'),
  makeUser('u-c1', 'khach@4eyewear.demo', 'Nguyễn Minh Anh', '0912345678', 'customer', '2026-10-05', [
    makeAddress('a-c1', 'Nguyễn Minh Anh', '0912345678', 'Khánh Hòa', 'TP. Nha Trang', 'Phước Hải', '12 Trần Phú'),
  ]),
  makeUser('u-c2', 'tuan.le@example.com', 'Lê Anh Tuấn', '0987654321', 'customer', '2026-10-08', [
    makeAddress('a-c2', 'Lê Anh Tuấn', '0987654321', 'Hà Nội', 'Quận Cầu Giấy', 'Dịch Vọng', '45 Duy Tân'),
  ]),
  makeUser('u-c3', 'hoa.pham@example.com', 'Phạm Thu Hòa', '0977111222', 'customer', '2026-10-12', [
    makeAddress('a-c3', 'Phạm Thu Hòa', '0977111222', 'TP. Hồ Chí Minh', 'Quận 7', 'Tân Phú', '8 Nguyễn Thị Thập'),
  ]),
  makeUser('u-c4', 'duc.tran@example.com', 'Trần Minh Đức', '0966333444', 'customer', '2026-11-01', [
    makeAddress('a-c4', 'Trần Minh Đức', '0966333444', 'Đà Nẵng', 'Quận Hải Châu', 'Thạch Thang', '20 Bạch Đằng'),
  ]),
  makeUser('u-c5', 'lan.vo@example.com', 'Võ Thị Lan', '0944555666', 'customer', '2026-11-10', [
    makeAddress('a-c5', 'Võ Thị Lan', '0944555666', 'Cần Thơ', 'Quận Ninh Kiều', 'Cái Khế', '3 Hòa Bình'),
  ]),
  makeUser('u-c6', 'nam.do@example.com', 'Đỗ Hoài Nam', '0933777888', 'customer', '2026-11-16', [
    makeAddress('a-c6', 'Đỗ Hoài Nam', '0933777888', 'Thừa Thiên Huế', 'TP. Huế', 'Phú Hội', '17 Lê Lợi'),
  ]),
]

const makeOrder = ({ code, userId, items, status, created_at, note = '' }) => {
  const user = SEED_USERS.find((u) => u.id === userId)
  const addr = user.addresses[0]
  const lines = items.map(([productId, quantity]) => {
    const p = PRODUCTS.find((x) => x.id === productId)
    const unit = effectivePrice(p)
    return {
      product_id: p.id,
      product_name: p.name,
      product_image: p.image_url,
      list_price: p.price,
      unit_price: unit,
      quantity,
      subtotal: unit * quantity,
    }
  })
  const subtotal = lines.reduce((sum, l) => sum + l.list_price * l.quantity, 0)
  const total = lines.reduce((sum, l) => sum + l.subtotal, 0)
  return {
    id: `o-${code}`,
    order_code: code,
    user_id: userId,
    customer_name: user.full_name,
    customer_email: user.email,
    customer_phone: user.phone,
    recipient_name: addr.recipient_name,
    recipient_phone: addr.phone,
    shipping_address: formatAddress(addr),
    items: lines,
    subtotal,
    discount: subtotal - total,
    total_amount: total,
    payment_method: 'COD',
    payment_status: status === 'Đã giao hàng' ? 'Đã thanh toán' : 'Chưa thanh toán',
    status,
    note,
    created_at,
    updated_at: created_at,
  }
}

export const SEED_ORDERS = [
  makeOrder({ code: '4EW-100201', userId: 'u-c1', items: [['p1', 1], ['p12', 2]], status: 'Đã giao hàng', created_at: '2026-11-03T14:20:00+07:00' }),
  makeOrder({ code: '4EW-100245', userId: 'u-c2', items: [['p2', 1]], status: 'Đã giao hàng', created_at: '2026-11-08T09:10:00+07:00' }),
  makeOrder({ code: '4EW-100289', userId: 'u-c3', items: [['p10', 2], ['p11', 1]], status: 'Đã giao hàng', created_at: '2026-11-12T16:45:00+07:00', note: 'Giao giờ hành chính' }),
  makeOrder({ code: '4EW-100310', userId: 'u-c1', items: [['p9', 1]], status: 'Đang giao hàng', created_at: '2026-11-22T11:05:00+07:00' }),
  makeOrder({ code: '4EW-100322', userId: 'u-c4', items: [['p4', 1], ['p8', 1]], status: 'Đã xác nhận', created_at: '2026-11-23T08:30:00+07:00' }),
  makeOrder({ code: '4EW-100331', userId: 'u-c5', items: [['p7', 1]], status: 'Chờ xác nhận', created_at: '2026-11-24T19:15:00+07:00' }),
  makeOrder({ code: '4EW-100335', userId: 'u-c6', items: [['p3', 2]], status: 'Đã hủy', created_at: '2026-11-19T10:00:00+07:00' }),
  makeOrder({ code: '4EW-100340', userId: 'u-c2', items: [['p5', 1], ['p12', 1]], status: 'Chờ xác nhận', created_at: '2026-11-25T08:30:00+07:00' }),
  makeOrder({ code: '4EW-100344', userId: 'u-c3', items: [['p2', 2]], status: 'Đã giao hàng', created_at: '2026-11-18T15:40:00+07:00' }),
]

// Dữ liệu lưu lượng 90 ngày gần nhất (mẫu) cho biểu đồ thống kê
function buildDailyStats(days = 30) {
  const today = new Date()
  const pad = (n) => String(n).padStart(2, '0')
  return Array.from({ length: days }, (_, i) => {
    const d = new Date(today)
    d.setDate(today.getDate() - (days - 1 - i))
    const visits = 90 + ((i * 37) % 70) + (i > 20 ? 25 : 0)
    const orders = (i * 5) % 4
    return {
      date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
      label: `${pad(d.getDate())}/${pad(d.getMonth() + 1)}`,
      visits,
      productViews: Math.round(visits * (2.1 + ((i * 7) % 5) / 10)),
      orders,
      revenue: orders * (650000 + ((i * 113000) % 500000)),
      newCustomers: (i * 3) % 5,
    }
  })
}

export const DAILY_STATS = buildDailyStats(90)

export const DEMO_ACCOUNTS = [
  { label: 'Khách hàng', email: 'khach@4eyewear.demo', password: 'demo123' },
  { label: 'Quản trị viên', email: 'admin@4eyewear.demo', password: 'admin123' },
]
