import Logo from '../common/Logo.jsx'

export default function Footer() {
  return (
    <footer className="mt-12 bg-ink text-white/70">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-8 px-4 py-10 lg:grid-cols-4 lg:px-6">
        <div className="col-span-2 lg:col-span-1">
          <Logo tone="dark" />
          <p className="mt-3 text-sm tracking-wide text-white/90">SEE THE WORLD DIFFERENTLY.</p>
          <p className="mt-3 text-sm leading-relaxed">
            4EYEWEAR là website mô phỏng thương mại điện tử, phục vụ môn Marketing số.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white">Hỗ trợ khách hàng</h4>
          <ul className="mt-3 space-y-2 text-sm">
            <li>Hướng dẫn mua hàng</li>
            <li>Thanh toán khi nhận hàng (COD)</li>
            <li>Theo dõi đơn hàng</li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white">Chính sách</h4>
          <ul className="mt-3 space-y-2 text-sm">
            <li>Điều khoản sử dụng</li>
            <li>Chính sách bảo mật</li>
            <li>Chính sách đổi trả (mô phỏng)</li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-white">Liên hệ</h4>
          <ul className="mt-3 space-y-2 text-sm">
            <li>Email: lienhe@4eyewear.demo</li>
            <li>Hotline: 0900 000 000 (demo)</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10 py-4 text-center text-xs">
        © 2026 4EYEWEAR. Dự án học tập, không phục vụ kinh doanh thực tế.
      </div>
    </footer>
  )
}
